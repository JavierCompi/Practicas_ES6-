const streamers = [
  { name: 'Rubius', age: 32, gameMorePlayed: 'Minecraft' },
  { name: 'Ibai', age: 25, gameMorePlayed: 'League of Legends' },
  { name: 'Reven', age: 43, gameMorePlayed: 'League of Legends' },
  { name: 'AuronPlay', age: 33, gameMorePlayed: 'Among Us' }
];

// Seleccionamos el input por su atributo 'data-function'
const input = document.querySelector('input[data-function="toFilterStreamers"]');

// Añadimos un event listener para el evento 'input'
input.addEventListener('input', (event) => {
  const searchText = event.target.value.toLowerCase(); // Capturamos el texto introducido y lo pasamos a minúsculas

  // Filtramos los streamers cuyos nombres incluyan el texto
  const filteredStreamers = streamers.filter(streamer => 
    streamer.name.toLowerCase().includes(searchText)
  );

  // Mostramos por consola el resultado del filtro
  console.log(filteredStreamers);